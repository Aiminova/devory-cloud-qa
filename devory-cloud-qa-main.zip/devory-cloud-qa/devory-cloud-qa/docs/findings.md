# Findings and Observations

> Status: these come from my review of the page content and metadata. Each one still needs to be confirmed in a browser and with a real account. Severity = impact, Priority = fix order.

## F-01 - Home, Login and Signup use the same page title
- **Severity:** Minor | **Priority:** P3 | **Type:** Accessibility / SEO
- **Observation:** `/`, `/login` and `/signup` share the `<title>` "Devory Cloud — Deploy from GitHub", while `/docs` and `/contact` have their own titles.
- **Expected:** A unique title that describes each page (for example "Log in · Devory Cloud"). WCAG 2.4.2.
- **Impact:** Screen reader and tab users cannot tell the pages apart; duplicate titles in search results.
- **Automation:** `test_key_pages_have_unique_titles` (tracked as xfail)

## F-02 - Login/Signup meta descriptions are generic and match the home page
- **Severity:** Trivial | **Priority:** P4
- **Suggestion:** Give auth pages a unique description or mark them `noindex`.

## F-03 - "Continue with Google" is shown although the feature is "coming soon"
- **Severity:** Minor | **Priority:** P3 | **Type:** UX
- **Observation:** The page says "Google sign-in will be available soon" but still presents the button.
- **To verify:** Is the button disabled (`disabled` / `aria-disabled`) and what happens on click?
- **Suggestion:** Show it as disabled with a "Coming soon" label to set the right expectation.

## F-04 - Paid plans have the same limits as Free
- **Severity:** Info | **Priority:** P3 | **Type:** Product / business rule
- **Observation:** Starter/Pro/Business say "same current limits"; the only difference is the inactivity exemption.
- **Risk:** Users may feel they pay without getting higher limits. The page is honest about it, but the billing flow needs clear messaging and testing (M-17, M-18, M-19) when it goes live.

## F-05 - Failed deployments consume the Free quota
- **Severity:** Minor | **Priority:** P3 | **Type:** UX / business rule
- **Observation:** According to the docs, a failed build still counts against the 5-updates-per-project limit.
- **Risk:** A new user can exhaust the quota with configuration mistakes. Suggestion: validate configuration before building and show a "remaining updates" warning.

## F-06 - ZIP upload is promoted on the home page, but docs have no dedicated section
- **Severity:** Minor | **Priority:** P3 | **Type:** Documentation
- **Observation:** The home page and the docs intro mention manual ZIP upload; the docs table of contents has no ZIP section.

## F-07 - Deployment preview shows "Progress 0%" next to completed steps
- **Severity:** Trivial | **Priority:** P4 | **Type:** Content consistency
- **Observation:** In the marketing visual, progress reads 0% while the steps say completed/published. It may be the initial state of an animation; to be verified in a browser.

---
## Bug Report Template
**Title:** [Module] Short summary · **Environment:** Browser/OS/viewport · **Severity / Priority** · **Steps** · **Actual** · **Expected** · **Attachments** (screenshot, HAR, console)
