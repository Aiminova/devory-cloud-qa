"""Page Object Model: login and signup pages.
Locators use accessible roles and labels instead of CSS selectors, so tests survive
markup changes and indirectly verify that the form is accessible."""
from playwright.sync_api import Page


class LoginPage:
    path = "/login"

    def __init__(self, page: Page):
        self.page = page
        self.heading = page.get_by_role("heading", level=1)
        self.email = page.get_by_label("Email", exact=True)
        self.password = page.get_by_label("Password", exact=True)
        self.submit = page.get_by_role("button", name="Log in with email")
        self.forgot_link = page.get_by_role("link", name="Forgot password?")
        self.signup_link = page.get_by_role("link", name="Create an account")

    def open(self):
        self.page.goto(self.path)
        return self

    def login(self, email: str, password: str):
        self.email.fill(email)
        self.password.fill(password)
        self.submit.click()


class SignupPage:
    path = "/signup"

    def __init__(self, page: Page):
        self.page = page
        self.heading = page.get_by_role("heading", level=1)
        self.name = page.get_by_label("Name", exact=True)
        self.email = page.get_by_label("Email", exact=True)
        self.password = page.get_by_label("Password", exact=True)
        self.submit = page.get_by_role("button", name="Create account with email")
        self.terms_link = page.get_by_role("link", name="Terms", exact=True)
        self.privacy_link = page.get_by_role("link", name="Privacy Policy")
        self.signin_link = page.get_by_role("link", name="Sign in")

    def open(self):
        self.page.goto(self.path)
        return self
