"""PASSIVE security checks: only things a normal browser can already see.
No attacks, brute force or load testing."""
import re
import warnings
import pytest
import requests
from playwright.sync_api import Page
from conftest import BASE_URL

pytestmark = pytest.mark.security


@pytest.mark.smoke
def test_http_redirects_to_https():
    r = requests.get(BASE_URL.replace("https://", "http://", 1), allow_redirects=False, timeout=15)
    assert r.status_code in (301, 302, 307, 308)
    assert r.headers["Location"].startswith("https://")


def test_recommended_security_headers_report():
    """Missing headers do NOT fail the test; they are reported as warnings (finding-level)."""
    r = requests.get(BASE_URL, timeout=15)
    h = {k.lower(): v for k, v in r.headers.items()}
    missing = []
    if "strict-transport-security" not in h:
        missing.append("Strict-Transport-Security")
    if h.get("x-content-type-options", "").lower() != "nosniff":
        missing.append("X-Content-Type-Options: nosniff")
    if "x-frame-options" not in h and "frame-ancestors" not in h.get("content-security-policy", ""):
        missing.append("X-Frame-Options or CSP frame-ancestors")
    if "content-security-policy" not in h:
        missing.append("Content-Security-Policy")
    if "referrer-policy" not in h:
        missing.append("Referrer-Policy")
    if missing:
        warnings.warn("Missing security headers: " + ", ".join(missing))
    assert r.status_code == 200


def test_server_header_does_not_leak_version():
    r = requests.get(BASE_URL, timeout=15)
    server = r.headers.get("Server", "")
    if re.search(r"\d+\.\d+", server):
        warnings.warn(f"Server header leaks version information: {server}")


def test_no_mixed_content_on_home(page: Page):
    insecure = []
    page.on("request", lambda req: insecure.append(req.url) if req.url.startswith("http://") else None)
    page.goto("/")
    page.wait_for_load_state("networkidle")
    assert insecure == [], f"Insecure (http) requests: {insecure}"


@pytest.mark.parametrize("path", ["/", "/login"])
def test_cookies_are_secure(page: Page, path):
    page.goto(path)
    page.wait_for_load_state("networkidle")
    insecure = [c["name"] for c in page.context.cookies() if not c["secure"]]
    assert insecure == [], f"Cookies without the Secure flag: {insecure}"


def test_browser_console_errors_report(page: Page):
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.goto("/")
    page.wait_for_load_state("networkidle")
    if errors:
        warnings.warn(f"Console errors: {errors[:5]}")
