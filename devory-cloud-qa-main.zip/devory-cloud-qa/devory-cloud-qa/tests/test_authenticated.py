"""Read-only tests that need a real account.
Skipped automatically unless DEVORY_EMAIL and DEVORY_PASSWORD are set.
Run these only with your OWN test account; they do not create projects or trigger deployments."""
import re
import pytest
from playwright.sync_api import Page, expect
from conftest import DEVORY_EMAIL, DEVORY_PASSWORD
from pages.auth_pages import LoginPage

pytestmark = [
    pytest.mark.authenticated,
    pytest.mark.skipif(not (DEVORY_EMAIL and DEVORY_PASSWORD), reason="No test account configured"),
]


@pytest.fixture
def logged_in(page: Page) -> Page:
    LoginPage(page).open().login(DEVORY_EMAIL, DEVORY_PASSWORD)
    expect(page).to_have_url(re.compile(r"/dashboard"), timeout=15000)
    return page


def test_login_redirects_to_dashboard(logged_in):
    expect(logged_in).to_have_url(re.compile(r"/dashboard"))


@pytest.mark.parametrize("path", ["/dashboard/projects", "/dashboard/deployments",
                                  "/dashboard/usage", "/dashboard/billing", "/dashboard/github"])
def test_dashboard_sections_open_for_logged_in_user(logged_in, path):
    logged_in.goto(path)
    expect(logged_in).to_have_url(re.compile(re.escape(path)))
    assert logged_in.locator("h1").count() >= 1


def test_authenticated_user_is_not_shown_login_form(logged_in):
    logged_in.goto("/dashboard")
    expect(logged_in.get_by_role("button", name="Log in with email")).to_have_count(0)
