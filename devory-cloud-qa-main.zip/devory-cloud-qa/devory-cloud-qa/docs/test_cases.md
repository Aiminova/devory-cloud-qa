# Test Cases

## A. Automated cases
| ID | Area | Scenario | Expected | Test file |
|---|---|---|---|---|
| DC-01 | Home | Title and H1 | "Deploy from GitHub. Keep it simple." | test_home |
| DC-02 | Home | Nav links (Product, How it works, Pricing, Docs) | Visible | test_home |
| DC-03 | Home | "Start deploying" CTA | Goes to /signup | test_home |
| DC-04 | Pricing | Free $0, Starter $7, Pro $15, Business $35, Enterprise Custom | All listed | test_home |
| DC-05 | Pricing | Free limits: 3 projects, 5 updates, 500 MB | Visible | test_home |
| DC-06 | Policy | Inactivity: day 15 / 25 / 30 | Visible | test_home |
| DC-07 | SEO | description, og:*, twitter:card | Present | test_home |
| DC-08 | Legal | 5 legal links in the footer | Correct href | test_home |
| DC-09 | Login | Fields and buttons | Visible | test_auth_pages |
| DC-10 | Login | Password masked | type=password | test_auth_pages |
| DC-11 | Login | Empty submit | Stays on /login | test_auth_pages |
| DC-12 | Login | Wrong credentials | Not authenticated | test_auth_pages |
| DC-13 | Login | SQLi / XSS input | No bypass, no script execution | test_auth_pages |
| DC-14 | Signup | Fields, terms/privacy links | Correct | test_auth_pages |
| DC-15 | Signup | Empty / invalid email | Stays on /signup | test_auth_pages |
| DC-16 | Access | 7 dashboard paths, not logged in | Redirect to /login | test_access_control |
| DC-17 | Docs | 12 sections and table-of-contents link | Present, scrolls | test_static_pages |
| DC-18 | Consistency | Limits on home = docs | Same | test_static_pages |
| DC-19 | Pages | 11 public pages return 200; unknown page 404 | Correct codes | test_static_pages |
| DC-20 | Links | Internal links on home | <400 | test_static_pages |
| DC-21 | Security | HTTP->HTTPS, Secure cookies, mixed content | Pass | test_security_basics |
| DC-22 | Security | Security headers | Missing ones reported | test_security_basics |
| DC-23 | Responsive | 4 viewports x 4 pages, horizontal overflow | None | test_responsive_a11y |
| DC-24 | A11y | lang, single H1, alt, labeled inputs, Tab | Satisfied | test_responsive_a11y |
| DC-25 | Perf | Response <3 s, DCL <5 s, no failed requests | Satisfied | test_performance |
| DC-26 | Authenticated | Dashboard sections after login | Open | test_authenticated (optional) |

## B. Manual cases (login-protected business rules, based on the docs)
| ID | Rule | Steps | Expected | Priority |
|---|---|---|---|---|
| M-01 | 3-project limit | Create 3 projects on Free, try a 4th | 4th is blocked with a clear message | High |
| M-02 | Slug rules | Try spaces, uppercase, special characters, very long, existing slug | Invalid ones rejected, uniqueness enforced | High |
| M-03 | Slug -> URL | Publish a project | `https://<slug>.devorycloud.com` opens | Critical |
| M-04 | 5-update limit | Deploy 5 times on one project, try a 6th | 6th is blocked, Usage shows 5/5 | High |
| M-05 | Failed-deploy quota | Trigger an intentionally broken build | Failed deploy also consumes quota (per docs) | High |
| M-06 | Unsupported configuration | Invalid framework/build command | "Fail closed": clear error, nothing published | High |
| M-07 | Failed publish | Break the publish stage | Deployment is not marked success | Critical |
| M-08 | Deploy statuses and logs | Create and watch a deployment | queued -> building -> success/failed, logs and timing visible | High |
| M-09 | Deployment history | After several deploys | Ordered list with correct statuses | Medium |
| M-10 | GitHub connect | Connect via OAuth, list repos/branches | Listed correctly | Critical |
| M-11 | GitHub reconnect | Disconnect and reconnect | Projects are not deleted | High |
| M-12 | ZIP upload | Valid, corrupt and oversized ZIP | Valid publishes, others give clear errors | High |
| M-13 | 500 MB storage | Artifact near the limit | Over-limit is blocked | Medium |
| M-14 | Inactivity day 15/25/30 | Simulate dates (or use a test env) | Warning, final warning, archive | High |
| M-15 | Visitor traffic | Send traffic to the public URL | Does not reset the inactivity timer | Medium |
| M-16 | Archived project | Open URL after archive, then deploy again | Content not served first, restored by deploy | High |
| M-17 | Paid-plan exemption | Inactivity on a paid plan | Not archived | Medium |
| M-18 | Billing disabled state | Open /dashboard/billing | "Being activated" notice, no fake upgrade | Medium |
| M-19 | Payment verification | (When billing is on) send a fake success flag from the frontend | Plan does not change; only verified payment upgrades | Critical |
| M-20 | Access isolation | User A opens user B's project/deployment URL | Access denied | Critical |
| M-21 | Google sign-in | Click "Continue with Google" | Clearly communicated as not available, consistent button state | Low |
| M-22 | Password reset | Valid and invalid emails | No account information is revealed (same message) | High |
