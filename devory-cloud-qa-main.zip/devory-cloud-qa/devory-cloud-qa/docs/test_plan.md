# Test Plan - Devory Cloud (devorycloud.com)

## 1. Product Summary
Devory Cloud is a deployment SaaS (by Devory Tech) that connects a GitHub repository, configures a project and publishes it under `*.devorycloud.com`. It is in beta: no custom domains, paid plans currently share Free-plan limits, and billing is not fully active yet.

## 2. Objective
Verify that the public surface (marketing pages, authentication, documentation, legal pages) is correct, consistent, accessible and meets basic security expectations, and document the login-protected business rules as manual test cases.

## 3. Scope
| In scope (automation) | In scope (manual cases) | Out of scope |
|---|---|---|
| Home page content, pricing, navigation, SEO metadata | Project creation and the 3-project limit | Load/stress testing |
| Login/signup UI and negative input | 5-update limit, failed-deploy quota | Brute force, password guessing |
| Dashboard access control (unauthenticated) | GitHub OAuth connect/reconnect | Creating real accounts |
| Docs, contact, legal pages, broken links | ZIP upload, logs, deployment history | Payment flow (billing not active) |
| Responsive (4 viewports) and accessibility | Inactivity lifecycle (day 15/25/30) | Customers' published sites |
| Passive security: HTTPS, headers, cookies, mixed content | Archived project restored by a new deploy | Infrastructure internals |

## 4. Risk-Based Prioritization
| Risk | Impact | Likelihood | Priority | Mitigation |
|---|---|---|---|---|
| Unauthenticated user reaches the dashboard | Very high | Low | P1 | test_access_control (7 paths) |
| Login/signup does not work | Very high | Low | P1 | test_auth_pages |
| Limit/pricing info contradicts across pages | High (trust, legal) | Medium | P2 | consistency test |
| Legal pages or links are broken | High | Low | P2 | link scan, 200 checks |
| Broken mobile layout | Medium | Medium | P3 | responsive tests |
| Missing security headers | Medium | Medium | P3 | passive header report |

## 5. Approach and Techniques
Equivalence partitioning, boundary values (limits: 3 projects, 5 updates), negative testing, state transitions (inactivity lifecycle), cross-page consistency checks and exploratory testing. Automation uses Python, pytest, Playwright and requests with a Page Object Model and markers.

## 6. Rules of Engagement
- I use only read-only, low-volume requests; no attacks or load generation.
- The tests do not create accounts or projects and do not trigger deployments.
- Negative login tests use a nonexistent email and only a few attempts.
- Authenticated tests run only with my own test account via `.env` (never committed).
- These tests should only be run with the owner's permission or against my own systems.

## 7. Entry / Exit Criteria
- Entry: the site is reachable and dependencies are installed.
- Exit: all `smoke` tests pass, no Blocker/Critical finding is open, and findings are classified in `docs/findings.md`.

## 8. Known Limitations
The tests were written from the site's public content. If a test fails, it is either (a) a real finding or (b) the site's text or structure changed; I separate the two using the failure message and `findings.md`.
