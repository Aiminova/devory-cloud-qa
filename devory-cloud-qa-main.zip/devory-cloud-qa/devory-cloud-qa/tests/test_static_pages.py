"""Docs, contact and legal pages, cross-page consistency and a broken-link scan."""
import re
import warnings
import pytest
import requests
from playwright.sync_api import Page, expect
from conftest import BASE_URL

pytestmark = pytest.mark.content

LEGAL = ["/legal", "/legal/terms", "/legal/privacy", "/legal/refund",
         "/legal/acceptable-use", "/legal/cookies"]
DOC_SECTIONS = ["overview", "github", "project", "source", "deploy", "status",
                "history", "url", "limits", "inactivity", "reconnect", "billing"]


@pytest.mark.smoke
@pytest.mark.parametrize("path", ["/", "/login", "/signup", "/docs", "/contact"] + LEGAL)
def test_public_pages_return_200(page: Page, path):
    response = page.goto(path)
    assert response.status == 200
    assert page.title().strip() != ""


def test_unknown_route_returns_404(page: Page):
    response = page.goto("/this-page-definitely-does-not-exist-qa-12345")
    assert response.status == 404


def test_docs_heading_and_all_sections_exist(page: Page):
    page.goto("/docs")
    expect(page.get_by_role("heading", level=1)).to_have_text("Devory Cloud Documentation")
    for section_id in DOC_SECTIONS:
        assert page.locator(f"#{section_id}").count() == 1, f"Section #{section_id} not found"


def test_docs_toc_links_scroll_to_sections(page: Page):
    page.goto("/docs")
    page.get_by_role("link", name="Free plan limits").first.click()
    expect(page).to_have_url(re.compile(r"/docs#limits$"))


def test_contact_page_has_support_guidance(page: Page):
    page.goto("/contact")
    expect(page.get_by_role("heading", level=1)).to_have_text("Contact & Support")
    body = page.locator("body")
    expect(body).to_contain_text("Billing support")
    expect(body).to_contain_text("Do not email passwords")


def test_free_plan_limits_are_consistent_between_home_and_docs(page: Page):
    """Business-rule consistency: the same limit must not be written differently in two places."""
    page.goto("/")
    home = page.locator("body").inner_text()
    page.goto("/docs")
    docs = page.locator("body").inner_text()
    for fragment in (r"3 projects", r"500\s*MB"):
        assert re.search(fragment, home, re.I), f"Missing on home page: {fragment}"
        assert re.search(fragment, docs, re.I), f"Missing in docs: {fragment}"
    assert re.search(r"5 updates", home, re.I) and re.search(r"5 updates", docs, re.I)


@pytest.mark.xfail(reason="F-01: Home, /login and /signup share the same <title> (WCAG 2.4.2)",
                   strict=False)
def test_key_pages_have_unique_titles(page: Page):
    titles = {}
    for path in ("/", "/login", "/signup", "/docs", "/contact"):
        page.goto(path)
        titles[path] = page.title()
    assert len(set(titles.values())) == len(titles), titles


def test_internal_links_on_home_are_not_broken(page: Page):
    page.goto("/")
    hrefs = page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
    internal = sorted({h.split("#")[0].split("?")[0] for h in hrefs
                       if h.startswith(BASE_URL) and "cdn-cgi" not in h})
    assert internal, "No internal links found on the home page"
    broken = []
    for url in internal:
        status = requests.get(url, timeout=20).status_code
        if status >= 400:
            broken.append((url, status))
    assert not broken, f"Broken links: {broken}"


def test_external_company_link_is_alive():
    r = requests.get("https://devorytech.com", timeout=20)
    if r.status_code >= 400:
        warnings.warn(f"devorytech.com returned {r.status_code}")
    assert r.status_code < 500
