"""Home page: content, navigation, pricing and SEO metadata.
Expected values come from the live page and the /docs page."""
import re
import pytest
from playwright.sync_api import Page, expect

pytestmark = pytest.mark.content


@pytest.fixture
def home(page: Page) -> Page:
    page.goto("/")
    return page


@pytest.mark.smoke
def test_home_title_and_hero(home):
    expect(home).to_have_title(re.compile("Devory Cloud"))
    expect(home.get_by_role("heading", level=1)).to_have_text("Deploy from GitHub. Keep it simple.")


@pytest.mark.parametrize("name", ["Product", "How it works", "Pricing", "Docs"])
def test_main_navigation_links_visible(home, name):
    expect(home.get_by_role("link", name=name).first).to_be_visible()


@pytest.mark.smoke
def test_primary_cta_goes_to_signup(home):
    home.get_by_role("link", name="Start deploying").first.click()
    expect(home).to_have_url(re.compile(r"/signup$"))


def test_login_link_goes_to_login(home):
    home.get_by_role("link", name="Log in").first.click()
    expect(home).to_have_url(re.compile(r"/login$"))


@pytest.mark.parametrize(
    "pattern",
    [r"Free", r"\$0\s*/\s*month", r"\$7\s*/\s*month", r"\$15\s*/\s*month",
     r"\$35\s*/\s*month", r"Enterprise", r"Custom"],
)
def test_pricing_plans_are_listed(home, pattern):
    expect(home.locator("body")).to_contain_text(re.compile(pattern, re.I))


def test_free_plan_limits_are_stated(home):
    body = home.locator("body")
    expect(body).to_contain_text(re.compile(r"3 projects", re.I))
    expect(body).to_contain_text(re.compile(r"5 updates/project", re.I))
    expect(body).to_contain_text(re.compile(r"500 MB", re.I))


@pytest.mark.parametrize("day", ["15", "25", "30"])
def test_inactivity_lifecycle_days_are_shown(home, day):
    expect(home.locator("body")).to_contain_text(re.compile(rf"day\s*{day}", re.I))


def test_beta_limitation_is_communicated(home):
    expect(home.locator("body")).to_contain_text("Custom domains are not available in this beta.")


def test_pricing_anchor_opens_pricing_section(page):
    page.goto("/?section=pricing")
    expect(page.get_by_role("heading", name="Simple pricing.")).to_be_visible()


def test_seo_and_social_metadata(home):
    description = home.locator("meta[name='description']").get_attribute("content")
    assert description and "Devory Cloud" in description
    for prop in ("og:title", "og:description", "og:url"):
        assert home.locator(f"meta[property='{prop}']").count() == 1, f"{prop} is missing"
    expect(home.locator("meta[name='twitter:card']")).to_have_attribute("content", "summary_large_image")


@pytest.mark.parametrize(
    "link_name,href_part",
    [("Terms of Service", "/legal/terms"), ("Privacy Policy", "/legal/privacy"),
     ("Refund Policy", "/legal/refund"), ("Acceptable Use", "/legal/acceptable-use"),
     ("Cookie Policy", "/legal/cookies")],
)
def test_footer_legal_links(home, link_name, href_part):
    link = home.get_by_role("link", name=link_name).last
    expect(link).to_have_attribute("href", re.compile(re.escape(href_part)))
