"""Access control: a user who is not logged in must not see dashboard pages."""
import re
import pytest
import requests
from playwright.sync_api import Page, expect
from conftest import PROTECTED_PATHS, API_URL

pytestmark = pytest.mark.security


@pytest.mark.smoke
@pytest.mark.parametrize("path", PROTECTED_PATHS)
def test_dashboard_requires_authentication(page: Page, path):
    page.goto(path)
    # An unauthenticated user should be redirected to the login (or signup) page
    expect(page).to_have_url(re.compile(r"/(login|signup)"))


def test_api_host_is_reachable_over_https():
    r = requests.get(API_URL + "/", timeout=15)
    assert r.url.startswith("https://")
    assert r.status_code < 500, f"API server error: {r.status_code}"
