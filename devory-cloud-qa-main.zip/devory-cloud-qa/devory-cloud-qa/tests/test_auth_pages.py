"""Login and signup pages. IMPORTANT: no test creates a valid account.
Negative tests only use a nonexistent email or an invalid format, and send very few requests."""
import re
import pytest
from playwright.sync_api import Page, expect
from pages.auth_pages import LoginPage, SignupPage


@pytest.fixture
def login(page: Page) -> LoginPage:
    return LoginPage(page).open()


@pytest.fixture
def signup(page: Page) -> SignupPage:
    return SignupPage(page).open()


# ---------------- Login ----------------
@pytest.mark.smoke
def test_login_page_elements(login):
    expect(login.heading).to_have_text("Welcome to Devory Cloud")
    expect(login.email).to_be_visible()
    expect(login.password).to_be_visible()
    expect(login.submit).to_be_visible()
    expect(login.page.get_by_text("Continue with GitHub")).to_be_visible()
    expect(login.page.get_by_text("Continue with Google")).to_be_visible()


def test_login_password_is_masked(login):
    expect(login.password).to_have_attribute("type", "password")


def test_login_forgot_password_link(login):
    login.forgot_link.click()
    expect(login.page).to_have_url(re.compile(r"/forgot-password$"))


def test_login_to_signup_link(login):
    login.signup_link.click()
    expect(login.page).to_have_url(re.compile(r"/signup$"))


@pytest.mark.negative
def test_login_empty_submit_stays_on_login(login):
    login.submit.click()
    login.page.wait_for_timeout(800)
    expect(login.page).to_have_url(re.compile(r"/login"))


@pytest.mark.negative
def test_login_wrong_credentials_do_not_authenticate(login):
    login.login("qa.nonexistent.user@example.com", "WrongPassword!123")
    login.page.wait_for_timeout(1500)
    expect(login.page).to_have_url(re.compile(r"/login"))
    assert "/dashboard" not in login.page.url


@pytest.mark.negative
def test_login_invalid_email_format_is_rejected(login):
    login.login("not-an-email", "SomePassword1!")
    login.page.wait_for_timeout(800)
    expect(login.page).to_have_url(re.compile(r"/login"))


@pytest.mark.security
@pytest.mark.parametrize("payload", ["' OR '1'='1", "<script>alert(1)</script>"],
                         ids=["sql-injection", "xss"])
def test_login_malicious_input_is_harmless(login, payload):
    dialogs = []
    login.page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
    login.login(payload, payload)
    login.page.wait_for_timeout(1000)
    assert dialogs == [], "The XSS payload was executed!"
    assert "/dashboard" not in login.page.url


# ---------------- Signup ----------------
@pytest.mark.smoke
def test_signup_page_elements(signup):
    expect(signup.heading).to_have_text("Create your Devory Cloud account")
    for field in (signup.name, signup.email, signup.password):
        expect(field).to_be_visible()
    expect(signup.submit).to_be_visible()


def test_signup_password_is_masked(signup):
    expect(signup.password).to_have_attribute("type", "password")


def test_signup_terms_and_privacy_links(signup):
    expect(signup.terms_link).to_have_attribute("href", re.compile(r"/legal/terms"))
    expect(signup.privacy_link).to_have_attribute("href", re.compile(r"/legal/privacy"))


def test_signup_to_login_link(signup):
    signup.signin_link.click()
    expect(signup.page).to_have_url(re.compile(r"/login$"))


@pytest.mark.negative
def test_signup_empty_submit_stays_on_signup(signup):
    signup.submit.click()
    signup.page.wait_for_timeout(800)
    expect(signup.page).to_have_url(re.compile(r"/signup"))


@pytest.mark.negative
def test_signup_invalid_email_format_is_rejected(signup):
    signup.name.fill("QA Tester")
    signup.email.fill("not-an-email")
    signup.password.fill("SomePassword1!")
    signup.submit.click()
    signup.page.wait_for_timeout(800)
    expect(signup.page).to_have_url(re.compile(r"/signup"))
