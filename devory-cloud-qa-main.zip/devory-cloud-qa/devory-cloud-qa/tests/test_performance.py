"""Lightweight performance checks (single requests, NOT a load test)."""
import pytest
import requests
from playwright.sync_api import Page
from conftest import BASE_URL

pytestmark = pytest.mark.perf


@pytest.mark.parametrize("path", ["/", "/login", "/docs"])
def test_server_response_time_under_3_seconds(path):
    r = requests.get(BASE_URL + path, timeout=15)
    assert r.status_code == 200
    assert r.elapsed.total_seconds() < 3, f"{path}: {r.elapsed.total_seconds():.2f}s"


def test_dom_content_loaded_under_5_seconds(page: Page):
    page.goto("/")
    ms = page.evaluate("performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd")
    assert ms < 5000, f"DOMContentLoaded: {ms:.0f} ms"


def test_no_failed_same_origin_requests_on_home(page: Page):
    failed = []
    page.on("response", lambda r: failed.append((r.url, r.status))
            if r.url.startswith(BASE_URL) and r.status >= 400 else None)
    page.goto("/")
    page.wait_for_load_state("networkidle")
    assert failed == [], f"Failed requests: {failed}"


def test_home_page_html_size_is_reasonable():
    r = requests.get(BASE_URL, timeout=15)
    assert len(r.content) < 1_000_000, f"HTML size: {len(r.content)} bytes"
