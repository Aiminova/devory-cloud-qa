"""Responsive design and basic accessibility (WCAG) checks."""
import re
import pytest
from playwright.sync_api import Page, expect

PAGES = ["/", "/login", "/signup", "/docs"]
VIEWPORTS = {"mobile-375": (375, 812), "tablet-768": (768, 1024),
             "laptop-1280": (1280, 720), "wide-1920": (1920, 1080)}


@pytest.mark.responsive
@pytest.mark.parametrize("path", PAGES)
@pytest.mark.parametrize("vp", VIEWPORTS.values(), ids=VIEWPORTS.keys())
def test_no_horizontal_scroll(page: Page, path, vp):
    page.set_viewport_size({"width": vp[0], "height": vp[1]})
    page.goto(path)
    page.wait_for_load_state("networkidle")
    overflow = page.evaluate("document.documentElement.scrollWidth - window.innerWidth")
    assert overflow <= 1, f"{path} {vp} horizontal overflow: {overflow}px"


@pytest.mark.responsive
def test_mobile_shows_menu_button(page: Page):
    page.set_viewport_size({"width": 375, "height": 812})
    page.goto("/")
    expect(page.get_by_role("button", name=re.compile("menu", re.I)).first).to_be_visible()


@pytest.mark.a11y
@pytest.mark.parametrize("path", PAGES)
def test_html_lang_attribute_is_set(page: Page, path):
    page.goto(path)
    assert page.locator("html").get_attribute("lang"), f"{path}: <html lang> is missing"


@pytest.mark.a11y
@pytest.mark.parametrize("path", PAGES)
def test_exactly_one_h1(page: Page, path):
    page.goto(path)
    assert page.locator("h1").count() == 1, f"{path}: the page should have exactly one h1"


@pytest.mark.a11y
@pytest.mark.parametrize("path", PAGES)
def test_images_have_alt_attribute(page: Page, path):
    page.goto(path)
    missing = page.eval_on_selector_all("img", "els => els.filter(e => !e.hasAttribute('alt')).map(e => e.src)")
    assert missing == [], f"Missing alt: {missing}"


@pytest.mark.a11y
@pytest.mark.parametrize("path", ["/login", "/signup"])
def test_form_inputs_have_accessible_labels(page: Page, path):
    page.goto(path)
    unlabeled = page.eval_on_selector_all(
        "input:not([type=hidden]):not([type=submit])",
        "els => els.filter(e => !(e.labels && e.labels.length) && !e.getAttribute('aria-label') "
        "&& !e.getAttribute('aria-labelledby')).map(e => e.name || e.type)")
    assert unlabeled == [], f"Unlabeled fields: {unlabeled}"


@pytest.mark.a11y
def test_keyboard_tab_moves_focus_into_page(page: Page):
    page.goto("/login")
    page.keyboard.press("Tab")
    assert page.evaluate("document.activeElement.tagName") != "BODY"
